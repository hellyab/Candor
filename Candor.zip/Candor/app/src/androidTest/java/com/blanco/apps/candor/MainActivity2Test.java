package com.blanco.apps.candor;

import static org.junit.Assert.*;

public class MainActivity2Test {

}